// ============================================================
// APPLICATION CONFIGURATION
// Centralized config for roles, permissions, navigation, and app settings
// ============================================================

// --- App Configuration ---
export const APP_CONFIG = {
  appName: 'StaffHub',
  appDescription: 'Staff Management System',
  version: '1.0.0',
  // DEVELOPMENT ONLY: This controls whether we use mock data or API
  // When backend is ready, change to 'api' and set VITE_API_BASE_URL
  dataMode: (import.meta.env.VITE_DATA_MODE || 'mock') as 'mock' | 'api',
  apiBaseUrl: import.meta.env.VITE_API_BASE_URL || '',
};

// --- Role Definitions ---
export const ROLES = {
  EMPLOYEE: 'Employee',
  HR_MANAGER: 'HR Manager',
  DEPT_MANAGER: 'Department Manager',
  TRAINING_COORD: 'Training Coordinator',
  GRIEVANCE_OFFICER: 'Grievance Officer',
  EVENT_ORGANIZER: 'Event Organizer',
} as const;

export type RoleType = (typeof ROLES)[keyof typeof ROLES];

// --- Permission Definitions ---
// Each permission maps to which roles have access
export const PERMISSIONS = {
  // Employee management
  'employees.view': [ROLES.HR_MANAGER, ROLES.DEPT_MANAGER],
  'employees.create': [ROLES.HR_MANAGER],
  'employees.edit': [ROLES.HR_MANAGER],
  'employees.delete': [ROLES.HR_MANAGER],
  'employees.view-all': [ROLES.HR_MANAGER],
  'employees.view-dept': [ROLES.DEPT_MANAGER],

  // Attendance
  'attendance.view': [ROLES.EMPLOYEE],//, ROLES.HR_MANAGER, ROLES.DEPT_MANAGER 
  'attendance.view-all': [ROLES.HR_MANAGER, ROLES.DEPT_MANAGER],
  'attendance.edit': [ROLES.HR_MANAGER],
  'attendance.delete': [ROLES.HR_MANAGER],

  // Leave management
  'leave.view': [ROLES.EMPLOYEE, ROLES.HR_MANAGER, ROLES.DEPT_MANAGER],
  'leave.create': [ROLES.EMPLOYEE],
  'leave.approve': [ROLES.HR_MANAGER, ROLES.DEPT_MANAGER],
  'leave.reject': [ROLES.HR_MANAGER, ROLES.DEPT_MANAGER],
  'leave.view-all': [ROLES.HR_MANAGER, ROLES.DEPT_MANAGER],

  // Performance
  'performance.view': [ROLES.EMPLOYEE, ROLES.HR_MANAGER, ROLES.DEPT_MANAGER],
  'performance.create': [ROLES.HR_MANAGER, ROLES.DEPT_MANAGER],
  'performance.edit': [ROLES.HR_MANAGER, ROLES.DEPT_MANAGER],
  'performance.view-all': [ROLES.HR_MANAGER],

  // Training
  'training.view': [ROLES.EMPLOYEE, ROLES.HR_MANAGER, ROLES.TRAINING_COORD],
  'training.create': [ROLES.TRAINING_COORD, ROLES.HR_MANAGER],
  'training.edit': [ROLES.TRAINING_COORD, ROLES.HR_MANAGER],
  'training.delete': [ROLES.TRAINING_COORD, ROLES.HR_MANAGER],
  'training.manage': [ROLES.TRAINING_COORD, ROLES.HR_MANAGER],

  // Events
  'events.view': [ROLES.EMPLOYEE, ROLES.HR_MANAGER, ROLES.EVENT_ORGANIZER],
  'events.create': [ROLES.EVENT_ORGANIZER, ROLES.HR_MANAGER],
  'events.edit': [ROLES.EVENT_ORGANIZER, ROLES.HR_MANAGER],
  'events.delete': [ROLES.EVENT_ORGANIZER, ROLES.HR_MANAGER],
  'events.manage': [ROLES.EVENT_ORGANIZER, ROLES.HR_MANAGER],
  'events.register': [ROLES.EMPLOYEE],

  // Grievances
  'grievances.view': [ROLES.EMPLOYEE, ROLES.HR_MANAGER, ROLES.GRIEVANCE_OFFICER, ROLES.DEPT_MANAGER],
  'grievances.create': [ROLES.EMPLOYEE],
  'grievances.manage': [ROLES.GRIEVANCE_OFFICER, ROLES.HR_MANAGER],
  'grievances.assign': [ROLES.GRIEVANCE_OFFICER, ROLES.HR_MANAGER],

  // Reports
  'reports.view': [ROLES.HR_MANAGER, ROLES.DEPT_MANAGER, ROLES.TRAINING_COORD, ROLES.EVENT_ORGANIZER, ROLES.GRIEVANCE_OFFICER],

  // Notifications
  'notifications.view': [ROLES.EMPLOYEE, ROLES.HR_MANAGER, ROLES.DEPT_MANAGER, ROLES.TRAINING_COORD, ROLES.GRIEVANCE_OFFICER, ROLES.EVENT_ORGANIZER],
} as const;

export type PermissionType = keyof typeof PERMISSIONS;

// --- Permission Checker ---
// Centralized function to check if a role has a permission
export function hasPermission(role: RoleType, permission: PermissionType): boolean {
  const allowedRoles: readonly string[] = PERMISSIONS[permission];
  return allowedRoles.includes(role);
}

// --- Navigation Configuration ---
// Each nav item defines: key, label, icon, path, and required permission
/*export const NAV_ITEMS = [
  { key: 'dashboard', label: 'Dashboard', icon: 'LayoutDashboard', path: '/dashboard' },
  { key: 'employees', label: 'Employees', icon: 'Users', path: '/employees', permission: 'employees.view' as PermissionType },
  { key: 'attendance', label: 'Attendance', icon: 'Clock', path: '/attendance' },
  { key: 'leave', label: 'Leave', icon: 'CalendarDays', path: '/leave' },
  { key: 'performance', label: 'Performance', icon: 'TrendingUp', path: '/performance' },
  { key: 'training', label: 'Training', icon: 'GraduationCap', path: '/training' },
  { key: 'events', label: 'Events', icon: 'Calendar', path: '/events' },
  { key: 'grievances', label: 'Grievances', icon: 'MessageSquareWarning', path: '/grievances' },
  { key: 'reports', label: 'Reports', icon: 'BarChart3', path: '/reports', permission: 'reports.view' as PermissionType },
  { key: 'notifications', label: 'Notifications', icon: 'Bell', path: '/notifications' },
  { key: 'profile', label: 'Profile', icon: 'User', path: '/profile' },
  { key: 'settings', label: 'Settings', icon: 'Settings', path: '/settings' },
];
//////////////////////////////////////////
export const NAV_ITEMS = [
  // =========================
  // MAIN / EMPLOYEE FEATURES
  // ========================= delay

  {
    key: 'dashboard',
    label: 'Dashboard',
    icon: 'LayoutDashboard',
    path: '/dashboard',
  },

  {
    key: 'attendance',
    label: 'Attendance',
    icon: 'Clock',
    path: '/attendance',
    permission: 'attendance.view' as PermissionType,
  },

  {
    key: 'leave',
    label: 'Leave',
    icon: 'CalendarDays',
    path: '/leave',
    permission: 'leave.view' as PermissionType,
  },

  {
    key: 'performance',
    label: 'Performance',
    icon: 'TrendingUp',
    path: '/performance',
    permission: 'performance.view' as PermissionType,
  },

  {
    key: 'training',
    label: 'Training',
    icon: 'GraduationCap',
    path: '/training',
    permission: 'training.view' as PermissionType,
  },

  {
    key: 'events',
    label: 'Events',
    icon: 'Calendar',
    path: '/events',
    permission: 'events.view' as PermissionType,
  },

  {
    key: 'grievances',
    label: 'Grievances',
    icon: 'MessageSquareWarning',
    path: '/grievances',
    permission: 'grievances.view' as PermissionType,
  },


  // =========================
  // MANAGEMENT
  // =========================

  {
    key: 'employees-management',
    label: 'Employees',
    icon: 'Users',
    path: '/employees',
    permission: 'employees.view' as PermissionType,
    group: 'management',
  },

  {
    key: 'attendance-management',
    label: 'Attendance Management',
    icon: 'Clock',
    path: '/attendance',
    permission: 'attendance.view-all' as PermissionType,
    group: 'management',
  },

  {
    key: 'leave-management',
    label: 'Leave Management',
    icon: 'CalendarDays',
    path: '/leave',
    permission: 'leave.view-all' as PermissionType,
    group: 'management',
  },

  {
    key: 'performance-management',
    label: 'Performance Management',
    icon: 'TrendingUp',
    path: '/performance',
    permission: 'performance.view-all' as PermissionType,
    group: 'management',
  },

  {
    key: 'training-management',
    label: 'Training Management',
    icon: 'GraduationCap',
    path: '/training',
    permission: 'training.manage' as PermissionType,
    group: 'management',
  },

  {
    key: 'event-management',
    label: 'Event Management',
    icon: 'Calendar',
    path: '/events',
    permission: 'events.manage' as PermissionType,
    group: 'management',
  },

  {
    key: 'grievance-management',
    label: 'Grievance Management',
    icon: 'MessageSquareWarning',
    path: '/grievances',
    permission: 'grievances.manage' as PermissionType,
    group: 'management',
  },

  {
    key: 'reports',
    label: 'Reports',
    icon: 'BarChart3',
    path: '/reports',
    permission: 'reports.view' as PermissionType,
    group: 'management',
  },


  // =========================
  // PERSONAL
  // =========================

  {
    key: 'notifications',
    label: 'Notifications',
    icon: 'Bell',
    path: '/notifications',
    permission: 'notifications.view' as PermissionType,
    group: 'personal',
  },

  {
    key: 'profile',
    label: 'Profile',
    icon: 'User',
    path: '/profile',
    group: 'personal',
  },

  {
    key: 'settings',
    label: 'Settings',
    icon: 'Settings',
    path: '/settings',
    group: 'personal',
  },
];


// Get navigation items for a specific role
export function getNavigationForRole(role: RoleType) {
  return NAV_ITEMS.filter((item) => {
    if (!item.permission) return true;
    return hasPermission(role, item.permission);
  });
}
*/

// ============================================================
// NAVIGATION CONFIGURATION
// ============================================================

export type NavigationGroup = 'main' | 'management' | 'personal';

export interface NavigationItem {
  key: string;
  label: string;
  icon: string;
  path: string;
  group: NavigationGroup;
  permission?: PermissionType;
}

// ============================================================
// NAVIGATION ITEMS
// ============================================================
//
// IMPORTANT:
//
// MAIN = normal employee features.
// These are available to EVERY authenticated employee.
//
// MANAGEMENT = additional role-based features.
// These require a permission.
//
// PERSONAL = available to EVERY authenticated employee.
//
// Employee and management pages intentionally have DIFFERENT
// paths. This prevents the management navigation item from
// accidentally opening the employee page.
// ============================================================

export const NAV_ITEMS: NavigationItem[] = [

  // ==========================================================
  // MAIN - EVERY EMPLOYEE
  // ==========================================================

  {
    key: 'dashboard',
    label: 'Dashboard',
    icon: 'LayoutDashboard',
    path: '/dashboard',
    group: 'main',
  },

  {
    key: 'attendance',
    label: 'Attendance',
    icon: 'Clock',
    path: '/attendance',
    group: 'main',
  },

  {
    key: 'leave',
    label: 'Leave',
    icon: 'CalendarDays',
    path: '/leave',
    group: 'main',
  },

  {
    key: 'performance',
    label: 'Performance',
    icon: 'TrendingUp',
    path: '/performance',
    group: 'main',
  },

  {
    key: 'training',
    label: 'Training',
    icon: 'GraduationCap',
    path: '/training',
    group: 'main',
  },

  {
    key: 'events',
    label: 'Events',
    icon: 'Calendar',
    path: '/events',
    group: 'main',
  },

  {
    key: 'grievances',
    label: 'Grievances',
    icon: 'MessageSquareWarning',
    path: '/grievances',
    group: 'main',
  },


  // ==========================================================
  // MANAGEMENT / ROLE-SPECIFIC FEATURES
  // ==========================================================

  {
    key: 'employees-management',
    label: 'Employees',
    icon: 'Users',
    path: '/management/employees',
    group: 'management',
    permission: 'employees.view',
  },

  {
    key: 'attendance-management',
    label: 'Attendance Management',
    icon: 'Clock',
    path: '/management/attendance',
    group: 'management',
    permission: 'attendance.view-all',
  },

  {
    key: 'leave-management',
    label: 'Leave Management',
    icon: 'CalendarDays',
    path: '/management/leave',
    group: 'management',
    permission: 'leave.view-all',
  },

  {
    key: 'performance-management',
    label: 'Performance Management',
    icon: 'TrendingUp',
    path: '/management/performance',
    group: 'management',
    permission: 'performance.view-all',
  },

  {
    key: 'training-management',
    label: 'Training Management',
    icon: 'GraduationCap',
    path: '/management/training',
    group: 'management',
    permission: 'training.manage',
  },

  {
    key: 'event-management',
    label: 'Event Management',
    icon: 'Calendar',
    path: '/management/events',
    group: 'management',
    permission: 'events.manage',
  },

  {
    key: 'grievance-management',
    label: 'Grievance Management',
    icon: 'MessageSquareWarning',
    path: '/management/grievances',
    group: 'management',
    permission: 'grievances.manage',
  },

  {
    key: 'reports',
    label: 'Reports',
    icon: 'BarChart3',
    path: '/management/reports',
    group: 'management',
    permission: 'reports.view',
  },


  // ==========================================================
  // PERSONAL - EVERY EMPLOYEE
  // ==========================================================

  {
    key: 'notifications',
    label: 'Notifications',
    icon: 'Bell',
    path: '/notifications',
    group: 'personal',
  },

  {
    key: 'profile',
    label: 'Profile',
    icon: 'User',
    path: '/profile',
    group: 'personal',
  },

  {
    key: 'settings',
    label: 'Settings',
    icon: 'Settings',
    path: '/settings',
    group: 'personal',
  },
];


// ============================================================
// MANAGEMENT SECTION TITLE
// ============================================================

export function getManagementLabel(role: RoleType): string | null {
  switch (role) {

    case ROLES.HR_MANAGER:
      return 'HR MANAGEMENT';

    case ROLES.DEPT_MANAGER:
      return 'DEPARTMENT MANAGEMENT';

    case ROLES.TRAINING_COORD:
      return 'TRAINING MANAGEMENT';

    case ROLES.GRIEVANCE_OFFICER:
      return 'GRIEVANCE MANAGEMENT';

    case ROLES.EVENT_ORGANIZER:
      return 'EVENT MANAGEMENT';

    case ROLES.EMPLOYEE:
    default:
      return null;
  }
}


// ============================================================
// GET NAVIGATION FOR ROLE
// ============================================================

export function getNavigationForRole(
  role: RoleType
): NavigationItem[] {

  return NAV_ITEMS.filter((item) => {

    // MAIN + PERSONAL
    // No permission means everyone can see it.
    if (!item.permission) {
      return true;
    }

    // MANAGEMENT
    // Permission is required.
    return hasPermission(role, item.permission);
  });
}





// --- Department List ---
export const DEPARTMENTS = [
  'Engineering',
  'Human Resources',
  'Finance',
  'Marketing',
  'Operations',
  'Sales',
  'Quality Assurance',
  'Research & Development',
];

// --- Leave Types ---
export const LEAVE_TYPES = ['Annual Leave', 'Sick Leave', 'Personal Leave', 'Maternity Leave', 'Paternity Leave', 'Unpaid Leave'];

// --- Attendance Statuses ---
export const ATTENDANCE_STATUSES = ['Present', 'Late', 'Absent', 'On Leave', 'Half Day'];

// --- Grievance Categories ---
export const GRIEVANCE_CATEGORIES = ['Workplace Issue', 'Harassment', 'Discrimination', 'Safety Concern', 'Policy Violation', 'Compensation', 'Other'];

// --- Grievance Priorities ---
export const GRIEVANCE_PRIORITIES = ['Low', 'Medium', 'High', 'Critical'];

// --- Grievance Statuses ---
export const GRIEVANCE_STATUSES = ['New', 'Under Review', 'Assigned', 'Resolved', 'Closed'];

// --- Training Categories ---
export const TRAINING_CATEGORIES = ['Technical', 'Leadership', 'Compliance', 'Soft Skills', 'Safety', 'Onboarding'];

// --- Event Categories ---
export const EVENT_CATEGORIES = ['Team Building', 'Conference', 'Workshop', 'Social', 'Celebration', 'Training', 'Meeting'];

// --- Performance Rating Scale ---
export const RATING_SCALE = [1, 2, 3, 4, 5] as const;

// --- Employee Statuses ---
export const EMPLOYEE_STATUSES = ['Active', 'On Leave', 'Probation', 'Terminated'];
